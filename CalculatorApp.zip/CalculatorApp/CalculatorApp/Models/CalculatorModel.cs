﻿namespace CalculatorApp.Models
{
    public class CalculatorModel
    {
        private double _firstNumber;
        private double _secondNumber;
        private string _operation;
        private bool _isNewNumber = true;

        public string CurrentDisplay { get; private set; } = "0";

        public void AppendNumber(string number)
        {
            if (_isNewNumber)
            {
                CurrentDisplay = number;
                _isNewNumber = false;
            }
            else
            {
                CurrentDisplay += number;
            }
        }

        public void SetOperation(string operation)
        {
            if (!_isNewNumber)
            {
                _firstNumber = double.Parse(CurrentDisplay);
                _operation = operation;
                _isNewNumber = true;
            }
        }

        public void Calculate()
        {
            if (_operation == null) return;

            _secondNumber = double.Parse(CurrentDisplay);

            switch (_operation)
            {
                case "+":
                    CurrentDisplay = (_firstNumber + _secondNumber).ToString();
                    break;
                case "-":
                    CurrentDisplay = (_firstNumber - _secondNumber).ToString();
                    break;
                case "×":
                    CurrentDisplay = (_firstNumber * _secondNumber).ToString();
                    break;
                case "÷":
                    if (_secondNumber == 0)
                    {
                        CurrentDisplay = "Błąd: dzielenie przez zero";
                    }
                    else
                    {
                        CurrentDisplay = (_firstNumber / _secondNumber).ToString();
                    }
                    break;
            }

            _operation = null;
            _isNewNumber = true;
        }

        public void Clear()
        {
            CurrentDisplay = "0";
            _firstNumber = 0;
            _secondNumber = 0;
            _operation = null;
            _isNewNumber = true;
        }
    }
}