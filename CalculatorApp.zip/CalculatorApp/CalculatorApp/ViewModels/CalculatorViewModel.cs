﻿using CalculatorApp.Models;
using System.Windows.Input;

namespace CalculatorApp.ViewModels
{
    public class CalculatorViewModel : BindableObject
    {
        private readonly CalculatorModel _calculator = new();

        public string Display
        {
            get => _calculator.CurrentDisplay;
            set
            {
                OnPropertyChanged(nameof(Display));
            }
        }

        public ICommand NumberCommand { get; }
        public ICommand OperationCommand { get; }
        public ICommand EqualsCommand { get; }
        public ICommand ClearCommand { get; }

        public CalculatorViewModel()
        {
            NumberCommand = new Command<string>(number =>
            {
                _calculator.AppendNumber(number);
                OnPropertyChanged(nameof(Display));
            });

            OperationCommand = new Command<string>(operation =>
            {
                _calculator.SetOperation(operation);
                OnPropertyChanged(nameof(Display));
            });

            EqualsCommand = new Command(() =>
            {
                _calculator.Calculate();
                OnPropertyChanged(nameof(Display));
            });

            ClearCommand = new Command(() =>
            {
                _calculator.Clear();
                OnPropertyChanged(nameof(Display));
            });
        }
    }
}