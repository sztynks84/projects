﻿namespace GraWKosci
{
    public partial class MainPage : ContentPage
    {
        Random rand = new Random();
        int wynikGry = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnButtonClicked(object? sender, EventArgs e)
        {
            int[] kosci = new int[5];

            // Losowanie
            for (int i = 0; i < 5; i++)
                kosci[i] = rand.Next(1, 7);

            // Ustaw obrazy
            Kosc1.Source = $"k{kosci[0]}.jpg";
            Kosc2.Source = $"k{kosci[1]}.jpg";
            Kosc3.Source = $"k{kosci[2]}.jpg";
            Kosc4.Source = $"k{kosci[3]}.jpg";
            Kosc5.Source = $"k{kosci[4]}.jpg";

            // Liczenie punktów
            int wynikLosowania = ObliczPunkty(kosci);

            wynikGry += wynikLosowania;

            WynikLosowaniaLabel.Text = $"Wynik tego losowania: {wynikLosowania}";
            WynikGryLabel.Text = $"Wynik gry: {wynikGry}";
        }

        private void OnResetClicked(object? sender, EventArgs e)
        {
            // Reset obrazków
            Kosc1.Source = "question.jpg";
            Kosc2.Source = "question.jpg";
            Kosc3.Source = "question.jpg";
            Kosc4.Source = "question.jpg";
            Kosc5.Source = "question.jpg";

            wynikGry = 0;

            WynikLosowaniaLabel.Text = "Wynik tego losowania: 0";
            WynikGryLabel.Text = "Wynik gry: 0";
        }

        private int ObliczPunkty(int[] kosci)
        {
            int suma = 0;

            for (int i = 1; i <= 6; i++)
            {
                int licznik = kosci.Count(k => k == i);

                if (licznik >= 2)
                    suma += i * licznik;
            }

            return suma;
        }
    }
}
