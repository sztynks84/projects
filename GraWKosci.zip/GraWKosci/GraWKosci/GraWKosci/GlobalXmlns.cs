[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "GraWKosci")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "GraWKosci.Pages")]
