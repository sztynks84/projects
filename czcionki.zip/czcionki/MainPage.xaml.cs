﻿using System;

namespace mobilna
{
    public partial class MainPage : ContentPage
    {
        string[] quotes = { "Dzień dobry", "Good morning", "Buenos dias" };
        int currentIndex = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSliderChanged(object sender, ValueChangedEventArgs e)
        {
            int size = (int)e.NewValue;

            SizeLabel.Text = $"Rozmiar: {size}";
            QuoteLabel.FontSize = size;
        }

        private void OnNextClicked(object sender, EventArgs e)
        {
            currentIndex++;

            if (currentIndex >= quotes.Length)
                currentIndex = 0;

            QuoteLabel.Text = quotes[currentIndex];
        }
    }
}