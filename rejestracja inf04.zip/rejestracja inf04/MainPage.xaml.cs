﻿namespace RejestracjaINF04;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnSubmit(object sender, EventArgs e)
    {
        string email = emailEntry.Text ?? "";
        string pass = passEntry.Text ?? "";
        string repeat = repeatPassEntry.Text ?? "";

        if (!email.Contains("@"))
        {
            resultLabel.Text = "Nieprawidłowy adres e-mail";
            return;
        }

        if (pass != repeat)
        {
            resultLabel.Text = "Hasła się różnią";
            return;
        }

        resultLabel.Text = $"Witaj {email}";
    }
}