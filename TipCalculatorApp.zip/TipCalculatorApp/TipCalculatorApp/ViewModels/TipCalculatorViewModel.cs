﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using TipCalculatorApp.Models;

namespace TipCalculatorApp.ViewModels
{
    public class TipCalculatorViewModel : INotifyPropertyChanged
    {
        private readonly TipCalculatorModel _model = new();

        public decimal BillAmount
        {
            get => _model.BillAmount;
            set
            {
                if (_model.BillAmount != value)
                {
                    _model.BillAmount = value;
                    OnPropertyChanged();
                    UpdateResults();
                }
            }
        }

        public int TipPercentage
        {
            get => _model.TipPercentage;
            set
            {
                if (_model.TipPercentage != value)
                {
                    _model.TipPercentage = value;
                    OnPropertyChanged();
                    UpdateResults();
                }
            }
        }

        public int NumberOfPeople
        {
            get => _model.NumberOfPeople;
            set
            {
                if (_model.NumberOfPeople != value && value >= 1)
                {
                    _model.NumberOfPeople = value;
                    OnPropertyChanged();
                    UpdateResults();
                }
            }
        }

        public decimal TotalPerPerson { get; private set; }
        public decimal TipAmount { get; private set; }
        public decimal TotalBill { get; private set; }

        public ICommand SetTipCommand { get; }
        public ICommand IncrementPeopleCommand { get; }
        public ICommand DecrementPeopleCommand { get; }

        public TipCalculatorViewModel()
        {
            SetTipCommand = new Command<string>(percentage =>
            {
                if (int.TryParse(percentage, out int tip))
                {
                    TipPercentage = tip;
                }
            });

            IncrementPeopleCommand = new Command(() => NumberOfPeople++);
            DecrementPeopleCommand = new Command(() =>
            {
                if (NumberOfPeople > 1) NumberOfPeople--;
            });
        }

        private void UpdateResults()
        {
            TipAmount = _model.CalculateTip();
            TotalBill = _model.CalculateTotal();
            TotalPerPerson = _model.CalculatePerPerson();

            OnPropertyChanged(nameof(TipAmount));
            OnPropertyChanged(nameof(TotalBill));
            OnPropertyChanged(nameof(TotalPerPerson));
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}