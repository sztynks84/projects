﻿namespace TipCalculatorApp.Models
{
    public class TipCalculatorModel
    {
        public decimal BillAmount { get; set; }
        public int TipPercentage { get; set; } = 15;
        public int NumberOfPeople { get; set; } = 1;

        public decimal CalculateTip() => BillAmount * TipPercentage / 100;
        public decimal CalculateTotal() => BillAmount + CalculateTip();
        public decimal CalculatePerPerson() => CalculateTotal() / NumberOfPeople;
    }
}