﻿namespace RGBApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            // Tytuł okna z numerem zdającego (zastąp własnym numerem)
            Title = "Wzornik kolorów RGB. Wykonał: 00000000000";
        }

        /// <summary>
        /// Aktualizuje kolor dużego prostokąta przy każdym ruchu suwaka
        /// </summary>
        private void OnSliderValueChanged(object sender, ValueChangedEventArgs e)
        {
            int r = (int)SliderR.Value;
            int g = (int)SliderG.Value;
            int b = (int)SliderB.Value;

            // Aktualizacja etykiet tekstowych
            ValueR.Text = r.ToString();
            ValueG.Text = g.ToString();
            ValueB.Text = b.ToString();

            // Zmiana koloru tła dużego prostokąta
            LargeRectangle.BackgroundColor = Color.FromRgb(r, g, b);
        }

        /// <summary>
        /// Ustawia kolor małego prostokąta i tekst na podstawie aktualnych wartości suwaków
        /// </summary>
        private void OnPobierzClicked(object sender, EventArgs e)
        {
            int r = (int)SliderR.Value;
            int g = (int)SliderG.Value;
            int b = (int)SliderB.Value;

            // Ustawienie koloru małego prostokąta
            SmallRectangle.BackgroundColor = Color.FromRgb(r, g, b);

            // Ustawienie tekstu z wartościami RGB
            LabelResult.Text = $"{r}, {g}, {b}";
        }
    }
}