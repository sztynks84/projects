﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Maui.Controls;

namespace QuoteApp;

public partial class MainPage : ContentPage
{
    private List<string> quotes = new();
    private Random random = new();

    private readonly List<Color> colors = new()
    {
        Colors.LightBlue, Colors.LightGreen, Colors.LightPink,
        Colors.LightSalmon, Colors.LightYellow, Colors.MistyRose,
        Colors.AliceBlue, Colors.Lavender
    };

    public MainPage()
    {
        InitializeComponent();
        LoadQuotes();
    }

    private void LoadQuotes()
    {
        try
        {
            var filePath = Path.Combine(FileSystem.AppDataDirectory, "quotes.txt");

            // Kopiuj plik z zasobów jeśli nie istnieje
            if (!File.Exists(filePath))
            {
                using var stream = FileSystem.OpenAppPackageFileAsync("quotes.txt").Result;
                using var reader = new StreamReader(stream);
                var content = reader.ReadToEnd();
                File.WriteAllText(filePath, content);
            }

            quotes = File.ReadAllLines(filePath)
                         .Where(line => !string.IsNullOrWhiteSpace(line))
                         .ToList();

            if (quotes.Count == 0)
            {
                QuoteLabel.Text = "Błąd: Plik z cytatami jest pusty.";
            }
        }
        catch (Exception ex)
        {
            QuoteLabel.Text = $"Błąd podczas wczytywania cytatów: {ex.Message}";
        }
    }

    private void OnQuoteButtonClicked(object sender, EventArgs e)
    {
        if (quotes.Count == 0)
        {
            QuoteLabel.Text = "Brak cytatów do wyświetlenia.";
            return;
        }

        var index = random.Next(quotes.Count);
        QuoteLabel.Text = quotes[index];

        var colorIndex = random.Next(colors.Count);
        this.BackgroundColor = colors[colorIndex];
    }
}
