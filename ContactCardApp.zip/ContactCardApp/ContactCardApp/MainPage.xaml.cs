﻿namespace ContactCardApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            BindingContext = new Models.Person
            {
                Name = "Jan Kowalski",
                Email = "jan.kowalski@example.com",
                Phone = "+48 123 456 789",
                Address = "ul. Przykładowa 123\n00-001 Warszawa"
            };
        }
    }
}