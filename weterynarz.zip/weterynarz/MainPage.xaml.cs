﻿using System;

namespace mobilna
{
    public partial class MainPage : ContentPage
    {
        string selectedAnimal = "";
        string ownerName = "";
        string visitPurpose = "";

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnAnimalChanged(object sender, EventArgs e)
        {
            selectedAnimal = AnimalPicker.SelectedItem?.ToString();

            switch (selectedAnimal)
            {
                case "Pies":
                    AgeSlider.Maximum = 18;
                    break;
                case "Kot":
                    AgeSlider.Maximum = 20;
                    break;
                case "Świnka morska":
                    AgeSlider.Maximum = 9;
                    break;
            }
        }

        private void OnSliderChanged(object sender, ValueChangedEventArgs e)
        {
            int age = (int)e.NewValue;
            AgeLabel.Text = age.ToString();
        }

        private void OnOkClicked(object sender, EventArgs e)
        {
            ownerName = this.FindByName<Entry>(null)?.Text;
            visitPurpose = this.FindByName<Entry>(null)?.Text;

            string result = $"{ownerName}, {selectedAnimal}, {AgeLabel.Text}, {visitPurpose}, {VisitTime.Time}";

            ResultLabel.Text = result;
        }
    }
}