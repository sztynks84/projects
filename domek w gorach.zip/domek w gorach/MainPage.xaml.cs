﻿using System;

namespace mobilna
{
    public partial class MainPage : ContentPage
    {
        int likes = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnLikeClicked(object sender, EventArgs e)
        {
            likes++;
            UpdateLabel();
        }

        private void OnRemoveClicked(object sender, EventArgs e)
        {
            if (likes > 0)
                likes--;

            UpdateLabel();
        }

        private void UpdateLabel()
        {
            LikeLabel.Text = $"{likes} polubień";
        }
    }
}