﻿namespace Mobilna;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnZatwierdzClicked(object sender, EventArgs e)
    {
        if (int.TryParse(PralkaInput.Text, out int nr))
        {
            if (nr >= 1 && nr <= 12)
            {
                PralkaWynik.Text = "Numer prania: " + nr;
            }
        }
    }

    private void OnOdkurzaczClicked(object sender, EventArgs e)
    {
        if (OdkurzaczBtn.Text == "Włącz")
        {
            OdkurzaczBtn.Text = "Wyłącz";
            OdkurzaczStatus.Text = "Odkurzacz włączony";
        }
        else
        {
            OdkurzaczBtn.Text = "Włącz";
            OdkurzaczStatus.Text = "Odkurzacz wyłączony";
        }
    }
}